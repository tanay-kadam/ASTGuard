"""ASTGuard tests."""
