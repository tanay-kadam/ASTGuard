"""Tokenizer/source coordinate alignment."""

